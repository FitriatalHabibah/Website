<?php

namespace app\Config;

class DatabaseConfig
{
    // Setting database
    public $host = "127.0.0.1";
    public $user = "root";
    public $password = "root";
    public $database_name = "praktikumweb";
    public $port = 8889;
}